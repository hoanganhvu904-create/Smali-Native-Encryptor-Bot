.class public Lcom/my/newproject/iPKz49meJTUt;
.super Ljava/lang/Object;

.method static constructor <clinit>()V
    .registers 1

    const-string v0, "jVex8ze1SG"
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

.method public static native zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;
.end method
