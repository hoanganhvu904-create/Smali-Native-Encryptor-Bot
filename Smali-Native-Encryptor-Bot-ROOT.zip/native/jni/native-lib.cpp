#include <jni.h>
#include <cstddef>
#include <cstdint>
#include <cstdlib>

namespace {
constexpr jchar kXorKey = 0x46;
constexpr unsigned char kRegistrationXor = 0xAB;

// Recovered native method: length is stored in code unit 0 (length XOR 0x46),
// followed by UTF-16 code units XORed with 0x46. Any trailing padding is ignored.
jstring decodeString(JNIEnv* env, jclass /* owner */, jstring input) {
    if (env == nullptr || input == nullptr) {
        return nullptr;
    }

    const jsize sourceLength = env->GetStringLength(input);
    if (sourceLength < 1) {
        return nullptr;
    }

    const jchar* source = env->GetStringChars(input, nullptr);
    if (source == nullptr) {
        return nullptr;
    }

    const jint decodedLength = static_cast<jint>(source[0] ^ kXorKey);
    if (decodedLength <= 0 || decodedLength > sourceLength - 1) {
        env->ReleaseStringChars(input, source);
        return nullptr;
    }

    auto* decoded = static_cast<jchar*>(std::malloc(
        static_cast<std::size_t>(decodedLength) * sizeof(jchar)));
    if (decoded == nullptr) {
        env->ReleaseStringChars(input, source);
        return nullptr;
    }

    for (jint i = 0; i < decodedLength; ++i) {
        decoded[i] = static_cast<jchar>(source[i + 1] ^ kXorKey);
    }

    jstring result = env->NewString(decoded, decodedLength);
    std::free(decoded);
    env->ReleaseStringChars(input, source);
    return result;
}

char* decodeRegistrationText(const unsigned char* encrypted, std::size_t length) {
    if (encrypted == nullptr) {
        return nullptr;
    }
    auto* plain = static_cast<char*>(std::malloc(length + 1));
    if (plain == nullptr) {
        return nullptr;
    }
    for (std::size_t i = 0; i < length; ++i) {
        plain[i] = static_cast<char>(encrypted[i] ^ kRegistrationXor);
    }
    plain[length] = '\0';
    return plain;
}
}  // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /* reserved */) {
    if (vm == nullptr) {
        return JNI_ERR;
    }

    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK ||
        env == nullptr) {
        return JNI_ERR;
    }

    // These byte arrays are the XOR-0xAB registration strings recovered from
    // the sample ELF's .rodata section.
    static constexpr unsigned char kClassName[] = {
        0xC8, 0xC4, 0xC6, 0x84, 0xC6, 0xD2, 0x84, 0xC5, 0xCE, 0xDC,
        0xDB, 0xD9, 0xC4, 0xC1, 0xCE, 0xC8, 0xDF, 0x84, 0xC2, 0xFB,
        0xE0, 0xD1, 0x9F, 0x92, 0xC6, 0xCE, 0xE1, 0xFF, 0xFE, 0xDF
    };
    static constexpr unsigned char kMethodName[] = {
        0xD1, 0xD8, 0xC5, 0xDD, 0xCC, 0xF3, 0xE0, 0xFD, 0xFA
    };
    static constexpr unsigned char kSignature[] = {
        0x83, 0xE7, 0xC1, 0xCA, 0xDD, 0xCA, 0x84, 0xC7, 0xCA, 0xC5,
        0xCC, 0x84, 0xF8, 0xDF, 0xD9, 0xC2, 0xC5, 0xCC, 0x90, 0x82,
        0xE7, 0xC1, 0xCA, 0xDD, 0xCA, 0x84, 0xC7, 0xCA, 0xC5, 0xCC,
        0x84, 0xF8, 0xDF, 0xD9, 0xC2, 0xC5, 0xCC, 0x90
    };

    char* className = decodeRegistrationText(kClassName, sizeof(kClassName));
    char* methodName = decodeRegistrationText(kMethodName, sizeof(kMethodName));
    char* signature = decodeRegistrationText(kSignature, sizeof(kSignature));

    if (className == nullptr || methodName == nullptr || signature == nullptr) {
        std::free(className);
        std::free(methodName);
        std::free(signature);
        return JNI_ERR;
    }

    jclass owner = env->FindClass(className);
    jint registrationResult = JNI_ERR;
    if (owner != nullptr) {
        JNINativeMethod methods[] = {
            {methodName, signature, reinterpret_cast<void*>(decodeString)}
        };
        registrationResult = env->RegisterNatives(owner, methods, 1);
        env->DeleteLocalRef(owner);
    }

    std::free(className);
    std::free(methodName);
    std::free(signature);

    return registrationResult == JNI_OK ? JNI_VERSION_1_6 : JNI_ERR;
}
