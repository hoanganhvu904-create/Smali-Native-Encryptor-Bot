LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE := jVex8ze1SG
LOCAL_SRC_FILES := native-lib.cpp
LOCAL_CPPFLAGS := -std=c++17 -fvisibility=hidden -Wall -Wextra

include $(BUILD_SHARED_LIBRARY)
