cmake_minimum_required(VERSION 3.18.1)
project(jVex8ze1SG LANGUAGES CXX)

add_library(jVex8ze1SG SHARED jni/native-lib.cpp)
target_compile_features(jVex8ze1SG PRIVATE cxx_std_17)
target_compile_options(jVex8ze1SG PRIVATE -fvisibility=hidden -Wall -Wextra)
