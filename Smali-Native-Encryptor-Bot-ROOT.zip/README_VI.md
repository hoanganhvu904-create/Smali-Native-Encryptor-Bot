# SMALI Native Encryptor Bot

Bộ mã nguồn này được dựng lại từ mẫu `done.zip` bạn gửi. Nó gồm bot Telegram nhận file `.smali`, mã C++ JNI tương đương với logic đã quan sát trong thư viện `.so`, lớp Smali wrapper và workflow GitHub Actions để build thư viện ARM64.

## 1. Kết quả reverse-engineering từ mẫu

Đã kiểm tra trực tiếp `libjVex8ze1SG.so` trong `done.zip`:

- ELF 64-bit, ARM AArch64, Android API 24, thư viện đã strip.
- Chỉ export `JNI_OnLoad`; hàm native được đăng ký động bằng `RegisterNatives`.
- Lớp được đăng ký: `com/my/newproject/iPKz49meJTUt`.
- Hàm native: `zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;`.
- Chuỗi đăng ký trong `.rodata` được giải XOR `0xAB`.
- Chuỗi đầu vào là UTF-16: code unit đầu chứa `độ_dài XOR 0x46`; các code unit tiếp theo được XOR `0x46`. Phần đuôi dư được bỏ qua.
- Native dùng tương đương `GetStringLength`, `GetStringChars`, `NewString` và `ReleaseStringChars`.

Các giá trị mẫu được giải ra từ `MainActivity.smali` gồm `hello`, `tôi`, `ok` và `kích sồ`.

**Giới hạn quan trọng:** file `.so` đã biên dịch và strip không chứa project C/C++ gốc để khôi phục nguyên văn. `native/jni/native-lib.cpp` là bản tái dựng ở mức mã nguồn theo logic máy đã phân tích, không phải bản `.cpp` gốc của tác giả.

Đây là obfuscation XOR, không phải mã hóa bảo mật. Người phân tích APK vẫn có thể khôi phục chuỗi.

## 2. Chạy bot Telegram

Bot dùng thư viện chuẩn của Python, không cần cài `python-telegram-bot`.

### Linux / VPS

```bash
python3 --version
export BOT_TOKEN='TOKEN_DO_BOTFATHER_CAP'
python3 bot.py
```

### Termux Android

```bash
pkg update -y
pkg install python -y
cd /duong-dan/den/native_smali_encryptor
export BOT_TOKEN='TOKEN_DO_BOTFATHER_CAP'
python bot.py
```

Không gửi token bot cho người khác và không đưa token vào file công khai trên GitHub.

Trong Telegram, gửi một file `.smali` dưới dạng Document. Bot sẽ mã hóa các lệnh `const-string` trong file đó và chèn sau mỗi lệnh:

```smali
invoke-static {v0}, Lcom/my/newproject/iPKz49meJTUt;->zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;
move-result-object v0
```

Bot chỉ nhận một file `.smali` mỗi lần; không tự giải nén APK/ZIP. Lệnh `const-string` đã có lời gọi JNI liền sau đó sẽ được bỏ qua để tránh mã hóa hai lần. Chuỗi rỗng và literal không đọc được cũng được bỏ qua.

## 3. Tích hợp vào APK

1. Thêm `smali-iPKz49meJTUt.smali` vào đúng cây package, đổi tên file thành `iPKz49meJTUt.smali`.
2. Dùng đúng descriptor `Lcom/my/newproject/iPKz49meJTUt;`. Nếu đổi package, phải đổi đồng bộ trong `bot.py`, file Smali wrapper và `native-lib.cpp`.
3. Build thư viện native, sau đó chép `libjVex8ze1SG.so` vào `lib/arm64-v8a/libjVex8ze1SG.so` trong APK.
4. Giữ file wrapper nguyên trạng; không gửi wrapper vào bot để mã hóa.
5. Build APK, cài thử trên thiết bị ARM64 Android 10 và xem logcat nếu có lỗi `UnsatisfiedLinkError`, `RegisterNatives` hoặc `No implementation found`.

Mẫu bạn cung cấp chỉ có `arm64-v8a`. Bộ này cũng chỉ cấu hình build ARM64. Thiết bị 32-bit cần thêm ABI và build riêng.

## 4. Build thư viện bằng GitHub Actions

Đưa cả thư mục lên GitHub. Mở tab **Actions** → **Build JNI native library** → **Run workflow**. Sau khi workflow thành công, tải artifact `native-libs-arm64-v8a`; trong đó có `libjVex8ze1SG.so`.

Cũng có thể build trong môi trường đã cài Android NDK:

```bash
cd native/jni
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk NDK_APPLICATION_MK=Application.mk NDK_LIBS_OUT=../../dist/libs NDK_OUT=../../build/obj
```

## 5. Kiểm thử bot

```bash
python -m unittest discover -s tests -v
```

Lưu ý: kiểm thử Python xác nhận định dạng XOR và thao tác Smali. Workflow GitHub Actions là nơi build `.so` cho ARM64; môi trường tạo gói này không có Android NDK nên chưa tạo được binary ARM64 trong gói.
