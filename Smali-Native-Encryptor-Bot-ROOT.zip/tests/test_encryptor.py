import unittest

import bot


class NativeEncryptorTests(unittest.TestCase):
    def test_encoder_matches_recovered_xor_format(self):
        body = bot.encrypt_for_native("hello", padding=0)
        encoded = bot.utf16_units(bot.decode_smali_literal(body))
        self.assertEqual(encoded[0] ^ 0x46, 5)
        self.assertEqual("".join(chr(c ^ 0x46) for c in encoded[1:6]), "hello")

    def test_process_injects_jni_call_and_result(self):
        source = (
            ".class public Ldemo/Test;\n"
            ".method public run()V\n"
            "    .registers 1\n"
            '    const-string v0, "Hello"\n'
            "    return-void\n"
            ".end method\n"
        )
        output, encrypted, skipped = bot.process_smali(source)
        self.assertEqual(encrypted, 1)
        self.assertEqual(skipped, 0)
        self.assertIn(
            "invoke-static {v0}, Lcom/my/newproject/iPKz49meJTUt;->"
            "zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;",
            output,
        )
        self.assertIn("move-result-object v0", output)

    def test_already_instrumented_constant_is_not_processed_twice(self):
        source = (
            ".class public Ldemo/Test;\n"
            ".method public run()V\n"
            "    .registers 1\n"
            '    const-string v0, "placeholder"\n'
            "\n"
            "    invoke-static {v0}, Lcom/my/newproject/iPKz49meJTUt;->"
            "zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;\n"
            "    move-result-object v0\n"
            "    return-void\n"
            ".end method\n"
        )
        _, encrypted, skipped = bot.process_smali(source)
        self.assertEqual(encrypted, 0)
        self.assertEqual(skipped, 1)

    def test_wrapper_file_is_protected(self):
        wrapper = (
            ".class public Lcom/my/newproject/iPKz49meJTUt;\n"
            ".super Ljava/lang/Object;\n"
        )
        with self.assertRaises(ValueError):
            bot.process_smali(wrapper)

    def test_empty_string_is_skipped(self):
        source = (
            ".class public Ldemo/Test;\n"
            ".method public run()V\n"
            "    .registers 1\n"
            '    const-string v0, ""\n'
            "    return-void\n"
            ".end method\n"
        )
        _, encrypted, skipped = bot.process_smali(source)
        self.assertEqual(encrypted, 0)
        self.assertEqual(skipped, 1)


if __name__ == "__main__":
    unittest.main()
