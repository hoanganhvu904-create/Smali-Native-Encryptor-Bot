#!/usr/bin/env python3
"""Telegram bot: encrypt const-string values for the recovered JNI XOR scheme.

No third-party Python packages are required. Set BOT_TOKEN before running.
"""
from __future__ import annotations

import json
import os
import random
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
API_ROOT = f"https://api.telegram.org/bot{BOT_TOKEN}" if BOT_TOKEN else ""
FILE_ROOT = f"https://api.telegram.org/file/bot{BOT_TOKEN}" if BOT_TOKEN else ""

# These must match the JNI wrapper class and native function below.
WRAPPER_DESCRIPTOR = os.environ.get(
    "WRAPPER_DESCRIPTOR", "Lcom/my/newproject/iPKz49meJTUt;"
).strip()
NATIVE_METHOD = "zsnvgXKVQ(Ljava/lang/String;)Ljava/lang/String;"
XOR_KEY = 0x46
MAX_FILE_BYTES = 10 * 1024 * 1024

CONST_STRING_RE = re.compile(
    r'^(?P<indent>[ \t]*)(?P<opcode>const-string(?:/jumbo)?)'
    r'(?P<gap>[ \t]+)(?P<register>[vp][0-9]+)[ \t]*,[ \t]*'
    r'"(?P<literal>(?:\\.|[^"\\])*)"[ \t]*(?:#.*)?$'
)


def decode_smali_literal(literal: str) -> str:
    """Decode the common Smali/Java string escapes."""
    # JSON handles \n, \t, \\, \", and \uXXXX. Smali may also escape \' .
    try:
        return json.loads('"' + literal.replace("\\'", "'") + '"')
    except Exception as exc:
        raise ValueError(f"Không đọc được chuỗi Smali: {exc}") from exc


def utf16_units(value: str) -> list[int]:
    raw = value.encode("utf-16-le", errors="surrogatepass")
    return [raw[i] | (raw[i + 1] << 8) for i in range(0, len(raw), 2)]


def units_to_smali_literal(units: list[int]) -> str:
    """Render UTF-16 code units as an ASCII-only Smali quoted-string body."""
    out: list[str] = []
    for unit in units:
        if unit == 0x22:
            out.append('\\"')
        elif unit == 0x5C:
            out.append('\\\\')
        elif 0x20 <= unit <= 0x7E:
            out.append(chr(unit))
        else:
            out.append(f"\\u{unit:04x}")
    return "".join(out)


def encrypt_for_native(value: str, padding: int | None = None) -> str:
    """Encode using the scheme recovered from libjVex8ze1SG.so.

    UTF-16 code unit 0 stores (plaintext UTF-16 length XOR 0x46).
    Each following plaintext UTF-16 code unit is XORed with 0x46.
    The native routine ignores the optional random tail; it is padding only.
    """
    plain = utf16_units(value)
    if not plain:
        raise ValueError("Chuỗi rỗng không giải mã được bằng hàm native trong mẫu.")
    if len(plain) > 0xFFFF:
        raise ValueError("Chuỗi vượt giới hạn 65535 đơn vị UTF-16.")

    encoded = [len(plain) ^ XOR_KEY]
    encoded.extend(unit ^ XOR_KEY for unit in plain)

    # Sample values had ~97–113 trailing noise characters. This padding has
    # no effect on the JNI decoder; it simply resembles the provided sample.
    pad_len = padding if padding is not None else random.randint(96, 116)
    noise_alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    encoded.extend(ord(random.choice(noise_alphabet)) for _ in range(max(0, pad_len)))
    return units_to_smali_literal(encoded)


def _next_code_line(lines: list[str], start: int) -> str:
    for line in lines[start:]:
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            return stripped
    return ""


def process_smali(source: str) -> tuple[str, int, int]:
    """Encrypt all const-string instructions and inject native decode calls.

    Returns (transformed_source, encrypted_count, skipped_count).
    """
    if WRAPPER_DESCRIPTOR in source and re.search(
        r"^\.class\b.*" + re.escape(WRAPPER_DESCRIPTOR), source, re.MULTILINE
    ):
        raise ValueError(
            "Đây là file lớp JNI wrapper. Không mã hóa file wrapper; hãy giữ nguyên "
            "để nó có thể load thư viện native."
        )

    lines = source.splitlines(keepends=True)
    output: list[str] = []
    encrypted = 0
    skipped = 0

    for index, original_line in enumerate(lines):
        body = original_line.rstrip("\r\n")
        ending = original_line[len(body):]
        match = CONST_STRING_RE.match(body)
        if not match:
            output.append(original_line)
            continue

        register = match.group("register")
        next_line = _next_code_line(lines, index + 1)
        expected_call = (
            f"invoke-static {{{register}}}, {WRAPPER_DESCRIPTOR}->"
            f"{NATIVE_METHOD}"
        )
        if next_line.startswith(expected_call):
            output.append(original_line)
            skipped += 1
            continue

        try:
            plain = decode_smali_literal(match.group("literal"))
            encoded_literal = encrypt_for_native(plain)
        except Exception:
            output.append(original_line)
            skipped += 1
            continue

        new_line = (
            f'{match.group("indent")}{match.group("opcode")}'
            f'{match.group("gap")}{register}, "{encoded_literal}"{ending}'
        )
        indent = match.group("indent")
        invoke_line = (
            f"{indent}invoke-static {{{register}}}, {WRAPPER_DESCRIPTOR}->"
            f"{NATIVE_METHOD}{ending or chr(10)}"
        )
        result_line = f"{indent}move-result-object {register}{ending or chr(10)}"
        output.extend((new_line, invoke_line, result_line))
        encrypted += 1

    return "".join(output), encrypted, skipped


def api_call(method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    if not BOT_TOKEN:
        raise RuntimeError("Chưa đặt biến môi trường BOT_TOKEN.")
    data = urllib.parse.urlencode(params or {}).encode("utf-8")
    request = urllib.request.Request(f"{API_ROOT}/{method}", data=data or None)
    with urllib.request.urlopen(request, timeout=45) as response:
        result = json.loads(response.read().decode("utf-8"))
    if not result.get("ok"):
        raise RuntimeError(f"Telegram API lỗi ở {method}: {result}")
    return result["result"]


def send_message(chat_id: int, text: str) -> None:
    api_call("sendMessage", {"chat_id": chat_id, "text": text})


def download_telegram_file(file_id: str, destination: Path) -> None:
    file_info = api_call("getFile", {"file_id": file_id})
    file_path = file_info.get("file_path")
    if not file_path:
        raise RuntimeError("Telegram không trả về đường dẫn file.")
    url = f"{FILE_ROOT}/{file_path}"
    with urllib.request.urlopen(url, timeout=60) as response:
        data = response.read(MAX_FILE_BYTES + 1)
    if len(data) > MAX_FILE_BYTES:
        raise ValueError("File quá lớn. Giới hạn bot đang đặt là 10 MB.")
    destination.write_bytes(data)


def send_document(chat_id: int, path: Path, caption: str) -> None:
    boundary = "----SmaliNativeEncryptorBoundary7MA4YWxk"
    parts: list[bytes] = []
    fields = {"chat_id": str(chat_id), "caption": caption}
    for key, value in fields.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{key}"\r\n\r\n'
            f"{value}\r\n".encode("utf-8")
        )
    file_data = path.read_bytes()
    parts.append(
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="document"; filename="{path.name}"\r\n'
        "Content-Type: application/octet-stream\r\n\r\n".encode("utf-8")
        + file_data
        + b"\r\n"
    )
    parts.append(f"--{boundary}--\r\n".encode("ascii"))
    body = b"".join(parts)
    request = urllib.request.Request(
        f"{API_ROOT}/sendDocument",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        result = json.loads(response.read().decode("utf-8"))
    if not result.get("ok"):
        raise RuntimeError(f"Không gửi được file: {result}")


def handle_update(update: dict[str, Any]) -> None:
    message = update.get("message") or update.get("edited_message")
    if not message:
        return
    chat_id = message.get("chat", {}).get("id")
    if not chat_id:
        return

    text = (message.get("text") or "").strip()
    if text.startswith("/start") or text.startswith("/help"):
        send_message(
            chat_id,
            "SMALI NATIVE ENCRYPTOR\n"
            "Gửi một file .smali để mã hóa tất cả lệnh const-string.\n"
            "Bot sẽ thêm lệnh gọi JNI zsnvgXKVQ sau từng chuỗi.\n"
            "Không gửi file JNI wrapper; giữ nguyên lớp wrapper và đặt "
            "libjVex8ze1SG.so vào đúng thư mục ABI của APK.",
        )
        return

    document = message.get("document")
    if not document:
        send_message(chat_id, "Hãy gửi file .smali dưới dạng Document.")
        return

    original_name = document.get("file_name") or "input.smali"
    if not original_name.lower().endswith(".smali"):
        send_message(chat_id, "Bot hiện chỉ nhận file có đuôi .smali.")
        return
    if document.get("file_size", 0) > MAX_FILE_BYTES:
        send_message(chat_id, "File vượt giới hạn 10 MB.")
        return

    safe_name = Path(original_name).name
    temp_dir = Path("bot_work")
    temp_dir.mkdir(exist_ok=True)
    input_path = temp_dir / f"input_{int(time.time() * 1000)}.smali"
    output_path = temp_dir / (Path(safe_name).stem + "_native_encrypted.smali")

    try:
        download_telegram_file(document["file_id"], input_path)
        source = input_path.read_text(encoding="utf-8-sig")
        transformed, encrypted_count, skipped_count = process_smali(source)
        if encrypted_count == 0:
            if skipped_count:
                reply = (
                    "Không có chuỗi mới để mã hóa. File có thể đã được xử lý "
                    "bằng lời gọi JNI zsnvgXKVQ, hoặc chứa chuỗi rỗng/không đọc được."
                )
            else:
                reply = (
                    "Không tìm thấy lệnh const-string hợp lệ trong file Smali. "
                    "Hãy gửi file lớp ứng dụng, không phải file JNI wrapper."
                )
            send_message(chat_id, reply)
            return
        output_path.write_text(transformed, encoding="utf-8")
        caption = (
            f"Đã mã hóa {encrypted_count} chuỗi bằng cơ chế JNI XOR 0x46. "
            f"Bỏ qua: {skipped_count}.\n"
            "Lưu ý: phải tích hợp đúng JNI wrapper và thư viện .so trước khi build APK."
        )
        send_document(chat_id, output_path, caption)
    except Exception as exc:
        send_message(chat_id, f"Không xử lý được file: {exc}")
    finally:
        for path in (input_path, output_path):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass


def main() -> None:
    if not BOT_TOKEN:
        print("Thiếu BOT_TOKEN. Hãy export BOT_TOKEN='token_bot_telegram' trước khi chạy.")
        raise SystemExit(2)

    print("Smali Native Encryptor Bot đang chạy. Nhấn Ctrl+C để dừng.")
    offset: int | None = None
    while True:
        try:
            params: dict[str, Any] = {"timeout": 25, "allowed_updates": '["message"]'}
            if offset is not None:
                params["offset"] = offset
            updates = api_call("getUpdates", params)
            for update in updates:
                offset = int(update["update_id"]) + 1
                try:
                    handle_update(update)
                except Exception as exc:
                    print(f"Lỗi xử lý update {update.get('update_id')}: {exc}", file=sys.stderr)
        except KeyboardInterrupt:
            print("Đã dừng bot.")
            return
        except (urllib.error.URLError, TimeoutError, RuntimeError, ValueError) as exc:
            print(f"Lỗi kết nối/API: {exc}", file=sys.stderr)
            time.sleep(3)


if __name__ == "__main__":
    main()
